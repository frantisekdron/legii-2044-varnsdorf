Legii 2044 – vizualizace ke schvaleni

Sada neobsahuje vizualizace pudy ani zahradni casti; ty zatim nejsou hotove.
